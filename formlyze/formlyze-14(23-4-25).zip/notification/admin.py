from django.contrib import admin
from .models import NotificationModel

# Register your models here.
admin.site.register(NotificationModel)